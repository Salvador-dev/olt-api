<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G2uJRaewB73GXezL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4NBS8On3rj2iP20v',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lCLLBvjHVGMpVEvI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bcvVsCc5zSSUg6Sp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/companies/listing' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::amfgGZOlb1RAARZe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v4v2SCplN558LE6o',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/tenancy/assets(?:/((?:.*)))?(*:36)|/a(?|pi/company/([^/]++)(*:67)|dmin/(?|companies/([^/]++)(?|(*:103))|permissions/([^/]++)(*:132)))|/([^/]++)/(?|c(?|hange/password(*:173)|apabilities(?|/(?|listing(*:206)|([^/]++)(?|(*:225)))|(*:235)))|user(?|/(?|listing(*:263)|([^/]++)(*:279)|roles/([^/]++)(*:301)|permissions/([^/]++)(*:329)|([^/]++)(?|(*:348)))|(*:358))|r(?|ole(?|/(?|listing(*:388)|([^/]++)(?|(*:407)))|(*:417))|eports(?|/(?|listing(*:446)|([^/]++)(*:462)|authorizations(*:484))|(*:493)))|p(?|ermission(?|/(?|listing(*:530)|([^/]++)(?|(*:549)))|(*:559))|onTypes/listing(*:583))|billing/(?|listing(*:610)|history(*:625)|([^/]++)(*:641)|history(*:656)|sendBill(*:672))|d(?|ashboard(?|(*:696)|/showByOlt/([^/]++)(*:723))|iagnostics(?|/(?|listing(*:756)|([^/]++)(?|(*:775)))|(*:785)))|locations(?|/(?|listing(*:818)|([^/]++)(?|(*:837)))|(*:847))|o(?|dbs(?|/(?|listing(*:877)|([^/]++)(?|(*:896)))|(*:906))|nu(?|s(?|/(?|listing(*:935)|configured(*:953)|unconfigured(*:973)|([^/]++)(?|(*:992))|authorize/([^/]++)(*:1019)|([^/]++)(*:1036)|showbyOlt/([^/]++)(*:1063)|get_(?|all_status/([^/]++)(*:1098)|running_config/([^/]++)(*:1130)))|(*:1141)|_imports(*:1158))|Types(?|/(?|listing(*:1187)|([^/]++)(?|(*:1207)))|(*:1218)))|lts(?|/(?|listing(*:1246)|([^/]++)(?|(*:1266)))|(*:1277)))|speed_profiles(?|/(?|listing(*:1316)|([^/]++)(?|(*:1336)))|(*:1347))|get(?|_olts_uptime_and_env_temperature(*:1395)|/(?|hardware(*:1416)|s(?|oftware(*:1436)|nmp/(?|portData/([^/]++)(*:1469)|uplink/([^/]++)(*:1493)|o(?|ltcard/([^/]++)(*:1521)|nu(?|s/([^/]++)(*:1545)|/([^/]++)(*:1563)))|vlan/([^/]++)(*:1587)|activeolt/([^/]++)(*:1614)|mode(?|l/([^/]++)(*:1640)|/([^/]++)(*:1658))|catv/([^/]++)(*:1681)|s(?|tatus/([^/]++)(*:1708)|ignal/([^/]++)(*:1731))|wan/([^/]++)(*:1753)))|uplinks/([^/]++)(*:1780)|vlans/([^/]++)(*:1803)|pon/([^/]++)(*:1824)))|vpn\\-tunnels(?|/(?|listing(*:1861)|([^/]++)(?|(*:1881)))|(*:1892))))/?$}sDu',
    ),
    3 => 
    array (
      36 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stancl.tenancy.asset',
            'path' => NULL,
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      67 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::edcvapJTTj8h3eEO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      103 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BBbHjuYPWAk7TMQv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xANOEHhKae0OIMJZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QclUQU4EzhVBqJlf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::08uB5eLKJMHdaAIp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ynyUMOKhM0QU7t10',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::73veQrMb7Kg5sZ6h',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aUBpNafQ7LG1s49a',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sbUB9XcMcHlbdY4F',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8hQpBBW2JXPll05m',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lHEXxxIibP0zsJOx',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ekalHqO5PgNSeJhN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1332DDMFSPVGPKCx',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tnG8T35AXFuFZjfD',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      329 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3NNHF1Vq5VRZm2Aw',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z81tOSkO5usXxcmf',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8ltyS3tdJ11VcKL5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      358 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4Lra46RfpfG4fBtT',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tqmpsqNuBssBvjq4',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::emjAw4gOClSFLLs2',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wrm2eOyHU0qNwR7n',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MPRgm03d3QAKjbsC',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zHkN4R42TSdpt7Pd',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oZJpwv40nIfDqhIK',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::86MHIRSbzt53tSzg',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      484 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CWrJLR9dFCHApqKa',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9nP3gzAchl9rbhIW',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LtMBgBShb6JDoJuu',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qeXk4s6QbZ8i7lg5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HuLw8hPlQpR2HZVW',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x57ykibAp3DNVF55',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      559 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LE2clhFDGVhsLazA',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      583 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jqNCBrqQ7USnOZCk',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      610 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kcjDApm8cU87jnu5',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      625 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fxwo04XarDg4nvz6',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ESORTrZbxVd45lC0',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      656 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zcaCihOVaye2Ayu1',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      672 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ySy4PvdqaD1Trfaz',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      696 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZA3q2pMxynFFVhGp',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      723 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ArXPXM7EXfIkTe0z',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      756 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NieLPApuCox1aRi3',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X5ayGgdHOL46yw3X',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MqYMTW6nWYmxUOCb',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YFaoZCaSzWrqe7Ag',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      785 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p87tD9yuSNSXmOra',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      818 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rl89ihpjrS6TzJuJ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mrJ1IbTVWHL7VvRx',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EFXkRdebUNIUm4yJ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FmzY5gkXYIKCGhQp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      847 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x4gK3JXJQxpjytCP',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      877 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wLqsQkH6fQdTvT02',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      896 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gTZ084SOsJaq41UT',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SPxy5eA2xRb0SpIV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AtyBPQmaQfkCrfoP',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      906 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hQEMDHAvzFqtjS8b',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qIT0jBtMJg3z931G',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      953 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WOOGySO1WAFbdXhD',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hmFwjB8pjBT5IQmD',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      992 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yfQUh4c3usqD51Gz',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1Ki4Kt1w9OifsdPz',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1019 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dtTMyGAFudcTsilD',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1036 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pQzFbyvgxGmXpgNv',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8nvCoEfQxvvEm60d',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1098 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LQFtjuklLMXRcSwR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LdHgfQRIha1M1Y01',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EEYj5P0cB43phpiQ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pSrk3KKmRSO573Cy',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EHsKXYk7uOvHtIwW',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1207 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2BqTLwKlECE8WsPQ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T0tEyOymQAZnMnX9',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RS8e33qk3rMzWBkk',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dqv9LFHg7xLiU0e3',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1246 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4zZWEomYoMM6nsub',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UUjpl3cLVQIe8EO7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vlRfDCBWkUbbuBB7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7JsedlnVrOUE1L5d',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::84EjvPuSTRnYPeJO',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SbkQC8NHqNgfRWHW',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hqrDcK9x8MdCm8AS',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QW5w1UkbcRDwHtO5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iGuZDtgjkBK6EmVN',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LUNQcB2rv4JMmHxt',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1347 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A0tAFoAGIn0askeO',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TLS0QnpR1UE8uaU7',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1416 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LCfQfEglktbvG63n',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kTzPbWWPl2uu8JD3',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1469 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::44oeoEemKw7p6ZNR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ucUoBFpg1BxIJDIN',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::79w6YUPsUX1PKSHC',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X84h60AjkXJhpoUs',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KnitPsPG3bxkwQtq',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1587 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GRNtZbAYZZNaa0V4',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ay6tboVNt9qYqPpP',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A67WrbArFVNFhNyR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1658 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LOoZ5UuV6GDlX75u',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1681 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4JW7Y608Kk7gvwF6',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZnWBKWrYdRZVDREY',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o52r5IuhbNevKMC5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1753 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E7CzBD0aSTC86Yt7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FkW5X6bMYLEco288',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1803 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MhUk35xspnk5RmCa',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1824 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AGQsM87IczOqg20X',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1861 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::16zPGqqsXk7xbFSu',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1881 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sKG6ss5wPyBiLCZT',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NyxN7eUKvINHaXM6',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IGkGwuDo5hjDjnsx',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1892 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::htCDCW7mLePgG77o',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stancl.tenancy.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tenancy/assets/{path?}',
      'action' => 
      array (
        'uses' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'controller' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'as' => 'stancl.tenancy.asset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::edcvapJTTj8h3eEO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@show',
        'controller' => 'App\\Http\\Controllers\\entity@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::edcvapJTTj8h3eEO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G2uJRaewB73GXezL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@registered',
        'controller' => 'App\\Http\\Controllers\\entity@registered',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::G2uJRaewB73GXezL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4NBS8On3rj2iP20v' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@login',
        'controller' => 'App\\Http\\Controllers\\entity@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::4NBS8On3rj2iP20v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lCLLBvjHVGMpVEvI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@logout',
        'controller' => 'App\\Http\\Controllers\\entity@logout',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lCLLBvjHVGMpVEvI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bcvVsCc5zSSUg6Sp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000073e0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bcvVsCc5zSSUg6Sp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::amfgGZOlb1RAARZe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/companies/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@index',
        'controller' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@index',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::amfgGZOlb1RAARZe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v4v2SCplN558LE6o' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@registered',
        'controller' => 'App\\Http\\Controllers\\entity@registered',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::v4v2SCplN558LE6o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BBbHjuYPWAk7TMQv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/companies/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@show',
        'controller' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@show',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::BBbHjuYPWAk7TMQv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xANOEHhKae0OIMJZ' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/companies/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@update',
        'controller' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@update',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::xANOEHhKae0OIMJZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QclUQU4EzhVBqJlf' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/companies/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\super_admin\\SuperAdminController@destroy',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::QclUQU4EzhVBqJlf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::08uB5eLKJMHdaAIp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/permissions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth.key',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'controller' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'namespace' => '',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::08uB5eLKJMHdaAIp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ynyUMOKhM0QU7t10' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/change/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ynyUMOKhM0QU7t10',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ekalHqO5PgNSeJhN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ekalHqO5PgNSeJhN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tqmpsqNuBssBvjq4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\RoleController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::tqmpsqNuBssBvjq4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zHkN4R42TSdpt7Pd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\RoleController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zHkN4R42TSdpt7Pd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::emjAw4gOClSFLLs2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@show',
        'controller' => 'App\\Http\\Controllers\\RoleController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::emjAw4gOClSFLLs2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wrm2eOyHU0qNwR7n' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::wrm2eOyHU0qNwR7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MPRgm03d3QAKjbsC' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\RoleController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::MPRgm03d3QAKjbsC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LtMBgBShb6JDoJuu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@index',
        'controller' => 'App\\Http\\Controllers\\PermissionController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LtMBgBShb6JDoJuu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LE2clhFDGVhsLazA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/permission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@store',
        'controller' => 'App\\Http\\Controllers\\PermissionController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LE2clhFDGVhsLazA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qeXk4s6QbZ8i7lg5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@show',
        'controller' => 'App\\Http\\Controllers\\PermissionController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qeXk4s6QbZ8i7lg5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HuLw8hPlQpR2HZVW' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@update',
        'controller' => 'App\\Http\\Controllers\\PermissionController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::HuLw8hPlQpR2HZVW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x57ykibAp3DNVF55' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::x57ykibAp3DNVF55',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4Lra46RfpfG4fBtT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4Lra46RfpfG4fBtT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1332DDMFSPVGPKCx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1332DDMFSPVGPKCx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tnG8T35AXFuFZjfD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getRoles',
        'controller' => 'App\\Http\\Controllers\\UserController@getRoles',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::tnG8T35AXFuFZjfD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3NNHF1Vq5VRZm2Aw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/permissions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'controller' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3NNHF1Vq5VRZm2Aw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z81tOSkO5usXxcmf' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::z81tOSkO5usXxcmf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8ltyS3tdJ11VcKL5' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8ltyS3tdJ11VcKL5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kcjDApm8cU87jnu5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/billing/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@index',
        'controller' => 'App\\Http\\Controllers\\BillingController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::kcjDApm8cU87jnu5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fxwo04XarDg4nvz6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/billing/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@history',
        'controller' => 'App\\Http\\Controllers\\BillingController@history',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fxwo04XarDg4nvz6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ESORTrZbxVd45lC0' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/billing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@update',
        'controller' => 'App\\Http\\Controllers\\BillingController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ESORTrZbxVd45lC0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zcaCihOVaye2Ayu1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/billing/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@storeHistory',
        'controller' => 'App\\Http\\Controllers\\BillingController@storeHistory',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zcaCihOVaye2Ayu1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ySy4PvdqaD1Trfaz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/billing/sendBill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillMailController@sendBill',
        'controller' => 'App\\Http\\Controllers\\BillMailController@sendBill',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ySy4PvdqaD1Trfaz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZA3q2pMxynFFVhGp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZA3q2pMxynFFVhGp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ArXPXM7EXfIkTe0z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard/showByOlt/{olt_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ArXPXM7EXfIkTe0z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rl89ihpjrS6TzJuJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@getData',
        'controller' => 'App\\Http\\Controllers\\ZoneController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::rl89ihpjrS6TzJuJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x4gK3JXJQxpjytCP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@store',
        'controller' => 'App\\Http\\Controllers\\ZoneController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::x4gK3JXJQxpjytCP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mrJ1IbTVWHL7VvRx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@show',
        'controller' => 'App\\Http\\Controllers\\ZoneController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::mrJ1IbTVWHL7VvRx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EFXkRdebUNIUm4yJ' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@update',
        'controller' => 'App\\Http\\Controllers\\ZoneController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::EFXkRdebUNIUm4yJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FmzY5gkXYIKCGhQp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'controller' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FmzY5gkXYIKCGhQp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wLqsQkH6fQdTvT02' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@getData',
        'controller' => 'App\\Http\\Controllers\\OdbsController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::wLqsQkH6fQdTvT02',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hQEMDHAvzFqtjS8b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/odbs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@store',
        'controller' => 'App\\Http\\Controllers\\OdbsController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::hQEMDHAvzFqtjS8b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gTZ084SOsJaq41UT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@show',
        'controller' => 'App\\Http\\Controllers\\OdbsController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::gTZ084SOsJaq41UT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SPxy5eA2xRb0SpIV' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@update',
        'controller' => 'App\\Http\\Controllers\\OdbsController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::SPxy5eA2xRb0SpIV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AtyBPQmaQfkCrfoP' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'controller' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AtyBPQmaQfkCrfoP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::73veQrMb7Kg5sZ6h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::73veQrMb7Kg5sZ6h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lHEXxxIibP0zsJOx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/capabilities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@store',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::lHEXxxIibP0zsJOx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aUBpNafQ7LG1s49a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@show',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::aUBpNafQ7LG1s49a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sbUB9XcMcHlbdY4F' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@update',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::sbUB9XcMcHlbdY4F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8hQpBBW2JXPll05m' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8hQpBBW2JXPll05m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oZJpwv40nIfDqhIK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@index',
        'controller' => 'App\\Http\\Controllers\\ReportController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::oZJpwv40nIfDqhIK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9nP3gzAchl9rbhIW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@store',
        'controller' => 'App\\Http\\Controllers\\ReportController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::9nP3gzAchl9rbhIW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::86MHIRSbzt53tSzg' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/reports/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@destroy',
        'controller' => 'App\\Http\\Controllers\\ReportController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::86MHIRSbzt53tSzg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CWrJLR9dFCHApqKa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/authorizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'controller' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CWrJLR9dFCHApqKa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NieLPApuCox1aRi3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NieLPApuCox1aRi3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p87tD9yuSNSXmOra' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/diagnostics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::p87tD9yuSNSXmOra',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X5ayGgdHOL46yw3X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::X5ayGgdHOL46yw3X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MqYMTW6nWYmxUOCb' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::MqYMTW6nWYmxUOCb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YFaoZCaSzWrqe7Ag' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::YFaoZCaSzWrqe7Ag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qIT0jBtMJg3z931G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@index',
        'controller' => 'App\\Http\\Controllers\\OnuController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qIT0jBtMJg3z931G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WOOGySO1WAFbdXhD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/configured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WOOGySO1WAFbdXhD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hmFwjB8pjBT5IQmD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/unconfigured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::hmFwjB8pjBT5IQmD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EEYj5P0cB43phpiQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@store',
        'controller' => 'App\\Http\\Controllers\\OnuController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::EEYj5P0cB43phpiQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yfQUh4c3usqD51Gz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@show',
        'controller' => 'App\\Http\\Controllers\\OnuController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::yfQUh4c3usqD51Gz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1Ki4Kt1w9OifsdPz' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@update',
        'controller' => 'App\\Http\\Controllers\\OnuController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1Ki4Kt1w9OifsdPz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dtTMyGAFudcTsilD' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/authorize/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'controller' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::dtTMyGAFudcTsilD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pQzFbyvgxGmXpgNv' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pQzFbyvgxGmXpgNv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8nvCoEfQxvvEm60d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/showbyOlt/{olt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8nvCoEfQxvvEm60d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LQFtjuklLMXRcSwR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_all_status/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LQFtjuklLMXRcSwR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LdHgfQRIha1M1Y01' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_running_config/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LdHgfQRIha1M1Y01',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pSrk3KKmRSO573Cy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus_imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pSrk3KKmRSO573Cy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hqrDcK9x8MdCm8AS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::hqrDcK9x8MdCm8AS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A0tAFoAGIn0askeO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/speed_profiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::A0tAFoAGIn0askeO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QW5w1UkbcRDwHtO5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QW5w1UkbcRDwHtO5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iGuZDtgjkBK6EmVN' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::iGuZDtgjkBK6EmVN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LUNQcB2rv4JMmHxt' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LUNQcB2rv4JMmHxt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4zZWEomYoMM6nsub' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getData',
        'controller' => 'App\\Http\\Controllers\\OltController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4zZWEomYoMM6nsub',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::84EjvPuSTRnYPeJO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@store',
        'controller' => 'App\\Http\\Controllers\\OltController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::84EjvPuSTRnYPeJO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UUjpl3cLVQIe8EO7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@show',
        'controller' => 'App\\Http\\Controllers\\OltController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UUjpl3cLVQIe8EO7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vlRfDCBWkUbbuBB7' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@update',
        'controller' => 'App\\Http\\Controllers\\OltController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::vlRfDCBWkUbbuBB7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7JsedlnVrOUE1L5d' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@destroy',
        'controller' => 'App\\Http\\Controllers\\OltController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::7JsedlnVrOUE1L5d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SbkQC8NHqNgfRWHW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@paginater',
        'controller' => 'App\\Http\\Controllers\\OltController@paginater',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::SbkQC8NHqNgfRWHW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TLS0QnpR1UE8uaU7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get_olts_uptime_and_env_temperature',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'controller' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::TLS0QnpR1UE8uaU7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LCfQfEglktbvG63n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getHardware',
        'controller' => 'App\\Http\\Controllers\\OltController@getHardware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LCfQfEglktbvG63n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kTzPbWWPl2uu8JD3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/software',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'controller' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::kTzPbWWPl2uu8JD3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FkW5X6bMYLEco288' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/uplinks/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'controller' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FkW5X6bMYLEco288',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MhUk35xspnk5RmCa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/vlans/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getVlans',
        'controller' => 'App\\Http\\Controllers\\OltController@getVlans',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::MhUk35xspnk5RmCa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AGQsM87IczOqg20X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/pon/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'controller' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AGQsM87IczOqg20X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EHsKXYk7uOvHtIwW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::EHsKXYk7uOvHtIwW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jqNCBrqQ7USnOZCk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/ponTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::jqNCBrqQ7USnOZCk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dqv9LFHg7xLiU0e3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onuTypes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::dqv9LFHg7xLiU0e3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2BqTLwKlECE8WsPQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::2BqTLwKlECE8WsPQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T0tEyOymQAZnMnX9' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::T0tEyOymQAZnMnX9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RS8e33qk3rMzWBkk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::RS8e33qk3rMzWBkk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::16zPGqqsXk7xbFSu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::16zPGqqsXk7xbFSu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::htCDCW7mLePgG77o' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/vpn-tunnels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::htCDCW7mLePgG77o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sKG6ss5wPyBiLCZT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::sKG6ss5wPyBiLCZT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NyxN7eUKvINHaXM6' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NyxN7eUKvINHaXM6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IGkGwuDo5hjDjnsx' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IGkGwuDo5hjDjnsx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::44oeoEemKw7p6ZNR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/portData/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::44oeoEemKw7p6ZNR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ucUoBFpg1BxIJDIN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/uplink/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ucUoBFpg1BxIJDIN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::79w6YUPsUX1PKSHC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/oltcard/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::79w6YUPsUX1PKSHC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GRNtZbAYZZNaa0V4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/vlan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::GRNtZbAYZZNaa0V4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X84h60AjkXJhpoUs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::X84h60AjkXJhpoUs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ay6tboVNt9qYqPpP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/activeolt/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'controller' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Ay6tboVNt9qYqPpP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A67WrbArFVNFhNyR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/model/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::A67WrbArFVNFhNyR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4JW7Y608Kk7gvwF6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/catv/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4JW7Y608Kk7gvwF6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZnWBKWrYdRZVDREY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZnWBKWrYdRZVDREY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o52r5IuhbNevKMC5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/signal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'controller' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::o52r5IuhbNevKMC5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E7CzBD0aSTC86Yt7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/wan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'controller' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::E7CzBD0aSTC86Yt7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LOoZ5UuV6GDlX75u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/mode/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LOoZ5UuV6GDlX75u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KnitPsPG3bxkwQtq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::KnitPsPG3bxkwQtq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
