<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::assrgbRd0wRM3hS7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GzBuWUDRNBBcc87c',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TIqidEmyffSzsECd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/tenancy/assets(?:/((?:.*)))?(*:36)|/api/company/([^/]++)(*:64)|/([^/]++)/(?|lo(?|g(?|in(*:95)|out(*:105))|cations(?|/(?|listing(*:135)|([^/]++)(?|(*:154)))|(*:164)))|c(?|hange/password(*:192)|apabilities(?|/(?|listing(*:225)|([^/]++)(?|(*:244)))|(*:254)))|user(?|/(?|listing(*:282)|([^/]++)(*:298)|roles/([^/]++)(*:320)|permissions/([^/]++)(*:348)|([^/]++)(?|(*:367)))|(*:377))|role(?|/(?|listing(*:404)|([^/]++)(?|(*:423)))|(*:433))|p(?|ermission(?|/(?|listing(*:469)|([^/]++)(?|(*:488)))|(*:498))|onTypes/listing(*:522))|dashboard(?|(*:543)|/showByOlt/([^/]++)(*:570))|o(?|dbs(?|/(?|listing(*:600)|([^/]++)(?|(*:619)))|(*:629))|nu(?|s(?|/(?|listing(*:658)|configured(*:676)|unconfigured(*:696)|([^/]++)(?|(*:715))|authorize/([^/]++)(*:742)|([^/]++)(*:758)|showbyOlt/([^/]++)(*:784)|get_(?|all_status/([^/]++)(*:818)|running_config/([^/]++)(*:849)))|(*:859)|_imports(*:875))|Types(?|/(?|listing(*:903)|([^/]++)(?|(*:922)))|(*:932)))|lts(?|/(?|listing(*:959)|([^/]++)(?|(*:978)))|(*:988)))|speed_profiles(?|/(?|listing(*:1026)|([^/]++)(?|(*:1046)))|(*:1057))|get(?|_olts_uptime_and_env_temperature(*:1105)|/(?|hardware(*:1126)|s(?|oftware(*:1146)|nmp/(?|portData/([^/]++)(*:1179)|uplink/([^/]++)(*:1203)|o(?|ltcard/([^/]++)(*:1231)|nu(?|s/([^/]++)(*:1255)|/([^/]++)(*:1273)))|vlan/([^/]++)(*:1297)|activeolt/([^/]++)(*:1324)|mode(?|l/([^/]++)(*:1350)|/([^/]++)(*:1368))|catv/([^/]++)(*:1391)|s(?|tatus/([^/]++)(*:1418)|ignal/([^/]++)(*:1441))|wan/([^/]++)(*:1463)))|uplinks/([^/]++)(*:1490)|vlans/([^/]++)(*:1513)|pon/([^/]++)(*:1534)))|vpn\\-tunnels(?|/(?|listing(*:1571)|([^/]++)(?|(*:1591)))|(*:1602))))/?$}sDu',
    ),
    3 => 
    array (
      36 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stancl.tenancy.asset',
            'path' => NULL,
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yYHVuvVSWGZ7KOg6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      95 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mHuXhQiGVPKhIq8H',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QWa1BfoTVnZGfMvJ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      135 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OgBVcqYWLlsUWP4t',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uvigdageoSFk3kMV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::opF3hVYP8kBBlQVo',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gYeEIJgy2C7cZTno',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4xNHteKImQnlQv8b',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cM9GXHnDyP3ZwEPK',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dms40fPDGUHeCW3z',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1BI3MoDfMIdS6GBw',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oBWKbBdNR4rfYfnn',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AxtJyEUjpgF6EIZy',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8uWsHQRfiQiKs8t2',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e11OJWNGmVY1ymEl',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t8OsDCVtAS49QpvV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sHyD4iwUM9dgPmVF',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2wBRtCd7EZLXYbgf',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uHkNxgO5QK16mMhY',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LRvAC5HHUesHNpOt',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SU6K6ntdmTMqCLTu',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7M6Jittu1DtIOz1X',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      423 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2mgCIoDRD6iDi4xm',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LqOk9JKnfF5Bu6HV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hQKGadANwAdpDv4m',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8TLNZkVRRzkTvhOj',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      469 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X1chyw1WQVJFCHoX',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      488 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2fjGMWiNMsPVRRwz',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::16AYyBgFPuUvfvEn',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fA7UOg2io6Xrt511',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      498 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3LqbbuPjnyR8akRZ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zp0IZObbAZeK17yz',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JhxiXpeBeO5KeYr0',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      570 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rYLg1mrOwYTsbWvX',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::og0QVwE9kuwhgVO4',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      619 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b9tTe4yxUu9I8yFV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JQNhAdzLBIz1Crpv',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eSukpFOv1Ih3lnrO',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      629 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FEgBQITBsRhc3UMV',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      658 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qpHvSgMAGJdrnOPm',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fIbR6ZzGfhVKLERn',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      696 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wOfB8zVwg8hWFScp',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      715 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U2kefUChyTotaETP',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IvlFNmIAeBxGqpF4',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3N9HXmQMa5SuzP4v',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      758 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1v6U6V3BsZQ2Be7R',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      784 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ri7FW0RmBq5O5Gp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      818 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sSR7UIHCBJwcbKTF',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d3EANE43SuUGHEyQ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      859 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ww6J3iPK4Zsd2M2B',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      875 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y8J2nfZSRvsFBCwq',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      903 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d04NRj0UDkaVEAsP',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      922 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uNiQJ6FH6fCH56Sw',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::83r8HNsb4c8bwn7H',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WR6tvCLHglnSuW7o',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WSUQUJEdoP1Q952l',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      959 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R1WSeND9lwF0mWol',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      978 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9eeIJdm9ZFBlISTN',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b2AVXyM1vojWYEXx',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::76Wu7D5AuN2e2fXl',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D5c7gW92DzmDNDYj',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bk1Rfda73grbyZCl',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1026 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZUf1J4UOoftO7wXY',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1046 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d3BcLDsYtsSOvkfd',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RvBQyKuCdygXu2rb',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uWeQIg9EKubIwCsr',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1057 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ij713W9vSWvnSfIO',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n7t29GFNdlwjDHIx',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rWPBDHNMaB2HZeh8',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1146 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gg8HIxNsawdcH6an',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1179 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CpmmMHpLlQJ8SJFz',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NRwL58iYR0h90iBW',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1231 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pW34bfijsDFbKyWI',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1255 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RaplG01G58iNjhqv',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1273 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dG6gsuam9ZKxCDNe',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9N4IfdjmZ87SvU9B',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b1yfok5HnqQE4VXQ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gxIWKqDWOUDyo9dI',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1368 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZPRIRUJfshK8LEKD',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1391 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y9Yx5RGR1tjxIW7p',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1418 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EbheAJNV8ZNDX9LX',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FE8Ie2FupvOkSa2O',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1463 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CFtIemBl4yOJXXV1',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0BlLVlLEqufM9Uun',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LEXVdUjNBTXu7zmy',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P4nMgLFHovtiXwbW',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AEUfQGAUyQY25nqH',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IQJxsuXGZIa5o3at',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ua3JmUtNO3GjdoxK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1CGhixmWstsBYFtr',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1602 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CF4qupq4a8hl8e3E',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stancl.tenancy.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tenancy/assets/{path?}',
      'action' => 
      array (
        'uses' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'controller' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'as' => 'stancl.tenancy.asset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::assrgbRd0wRM3hS7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@registered',
        'controller' => 'App\\Http\\Controllers\\entity@registered',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::assrgbRd0wRM3hS7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yYHVuvVSWGZ7KOg6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@show',
        'controller' => 'App\\Http\\Controllers\\entity@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::yYHVuvVSWGZ7KOg6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GzBuWUDRNBBcc87c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007f20000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GzBuWUDRNBBcc87c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TIqidEmyffSzsECd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@register',
        'namespace' => '',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TIqidEmyffSzsECd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mHuXhQiGVPKhIq8H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::mHuXhQiGVPKhIq8H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cM9GXHnDyP3ZwEPK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/change/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cM9GXHnDyP3ZwEPK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e11OJWNGmVY1ymEl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::e11OJWNGmVY1ymEl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7M6Jittu1DtIOz1X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\RoleController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::7M6Jittu1DtIOz1X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8TLNZkVRRzkTvhOj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\RoleController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8TLNZkVRRzkTvhOj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2mgCIoDRD6iDi4xm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@show',
        'controller' => 'App\\Http\\Controllers\\RoleController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::2mgCIoDRD6iDi4xm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LqOk9JKnfF5Bu6HV' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LqOk9JKnfF5Bu6HV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hQKGadANwAdpDv4m' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\RoleController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::hQKGadANwAdpDv4m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X1chyw1WQVJFCHoX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@index',
        'controller' => 'App\\Http\\Controllers\\PermissionController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::X1chyw1WQVJFCHoX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3LqbbuPjnyR8akRZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/permission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@store',
        'controller' => 'App\\Http\\Controllers\\PermissionController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3LqbbuPjnyR8akRZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2fjGMWiNMsPVRRwz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@show',
        'controller' => 'App\\Http\\Controllers\\PermissionController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::2fjGMWiNMsPVRRwz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::16AYyBgFPuUvfvEn' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@update',
        'controller' => 'App\\Http\\Controllers\\PermissionController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::16AYyBgFPuUvfvEn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fA7UOg2io6Xrt511' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fA7UOg2io6Xrt511',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SU6K6ntdmTMqCLTu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::SU6K6ntdmTMqCLTu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t8OsDCVtAS49QpvV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::t8OsDCVtAS49QpvV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sHyD4iwUM9dgPmVF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getRoles',
        'controller' => 'App\\Http\\Controllers\\UserController@getRoles',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::sHyD4iwUM9dgPmVF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2wBRtCd7EZLXYbgf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/permissions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'controller' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::2wBRtCd7EZLXYbgf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uHkNxgO5QK16mMhY' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uHkNxgO5QK16mMhY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LRvAC5HHUesHNpOt' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LRvAC5HHUesHNpOt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JhxiXpeBeO5KeYr0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::JhxiXpeBeO5KeYr0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rYLg1mrOwYTsbWvX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard/showByOlt/{olt_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::rYLg1mrOwYTsbWvX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OgBVcqYWLlsUWP4t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@getData',
        'controller' => 'App\\Http\\Controllers\\ZoneController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::OgBVcqYWLlsUWP4t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4xNHteKImQnlQv8b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@store',
        'controller' => 'App\\Http\\Controllers\\ZoneController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4xNHteKImQnlQv8b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uvigdageoSFk3kMV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@show',
        'controller' => 'App\\Http\\Controllers\\ZoneController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uvigdageoSFk3kMV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::opF3hVYP8kBBlQVo' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@update',
        'controller' => 'App\\Http\\Controllers\\ZoneController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::opF3hVYP8kBBlQVo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gYeEIJgy2C7cZTno' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'controller' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::gYeEIJgy2C7cZTno',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::og0QVwE9kuwhgVO4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@getData',
        'controller' => 'App\\Http\\Controllers\\OdbsController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::og0QVwE9kuwhgVO4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FEgBQITBsRhc3UMV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/odbs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@store',
        'controller' => 'App\\Http\\Controllers\\OdbsController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FEgBQITBsRhc3UMV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b9tTe4yxUu9I8yFV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@show',
        'controller' => 'App\\Http\\Controllers\\OdbsController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::b9tTe4yxUu9I8yFV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JQNhAdzLBIz1Crpv' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@update',
        'controller' => 'App\\Http\\Controllers\\OdbsController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::JQNhAdzLBIz1Crpv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eSukpFOv1Ih3lnrO' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'controller' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::eSukpFOv1Ih3lnrO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dms40fPDGUHeCW3z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::dms40fPDGUHeCW3z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8uWsHQRfiQiKs8t2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/capabilities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@store',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8uWsHQRfiQiKs8t2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1BI3MoDfMIdS6GBw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@show',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1BI3MoDfMIdS6GBw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oBWKbBdNR4rfYfnn' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@update',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::oBWKbBdNR4rfYfnn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AxtJyEUjpgF6EIZy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AxtJyEUjpgF6EIZy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qpHvSgMAGJdrnOPm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@index',
        'controller' => 'App\\Http\\Controllers\\OnuController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qpHvSgMAGJdrnOPm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fIbR6ZzGfhVKLERn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/configured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fIbR6ZzGfhVKLERn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wOfB8zVwg8hWFScp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/unconfigured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::wOfB8zVwg8hWFScp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ww6J3iPK4Zsd2M2B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@store',
        'controller' => 'App\\Http\\Controllers\\OnuController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Ww6J3iPK4Zsd2M2B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U2kefUChyTotaETP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@show',
        'controller' => 'App\\Http\\Controllers\\OnuController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::U2kefUChyTotaETP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IvlFNmIAeBxGqpF4' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@update',
        'controller' => 'App\\Http\\Controllers\\OnuController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IvlFNmIAeBxGqpF4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3N9HXmQMa5SuzP4v' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/authorize/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'controller' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3N9HXmQMa5SuzP4v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1v6U6V3BsZQ2Be7R' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1v6U6V3BsZQ2Be7R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ri7FW0RmBq5O5Gp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/showbyOlt/{olt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::7ri7FW0RmBq5O5Gp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sSR7UIHCBJwcbKTF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_all_status/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::sSR7UIHCBJwcbKTF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d3EANE43SuUGHEyQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_running_config/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::d3EANE43SuUGHEyQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y8J2nfZSRvsFBCwq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus_imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::y8J2nfZSRvsFBCwq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZUf1J4UOoftO7wXY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZUf1J4UOoftO7wXY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ij713W9vSWvnSfIO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/speed_profiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Ij713W9vSWvnSfIO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d3BcLDsYtsSOvkfd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::d3BcLDsYtsSOvkfd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RvBQyKuCdygXu2rb' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::RvBQyKuCdygXu2rb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uWeQIg9EKubIwCsr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uWeQIg9EKubIwCsr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R1WSeND9lwF0mWol' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getData',
        'controller' => 'App\\Http\\Controllers\\OltController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::R1WSeND9lwF0mWol',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D5c7gW92DzmDNDYj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@store',
        'controller' => 'App\\Http\\Controllers\\OltController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::D5c7gW92DzmDNDYj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9eeIJdm9ZFBlISTN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@show',
        'controller' => 'App\\Http\\Controllers\\OltController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::9eeIJdm9ZFBlISTN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b2AVXyM1vojWYEXx' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@update',
        'controller' => 'App\\Http\\Controllers\\OltController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::b2AVXyM1vojWYEXx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::76Wu7D5AuN2e2fXl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@destroy',
        'controller' => 'App\\Http\\Controllers\\OltController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::76Wu7D5AuN2e2fXl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bk1Rfda73grbyZCl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@paginater',
        'controller' => 'App\\Http\\Controllers\\OltController@paginater',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::bk1Rfda73grbyZCl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n7t29GFNdlwjDHIx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get_olts_uptime_and_env_temperature',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'controller' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::n7t29GFNdlwjDHIx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rWPBDHNMaB2HZeh8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getHardware',
        'controller' => 'App\\Http\\Controllers\\OltController@getHardware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::rWPBDHNMaB2HZeh8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gg8HIxNsawdcH6an' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/software',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'controller' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Gg8HIxNsawdcH6an',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0BlLVlLEqufM9Uun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/uplinks/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'controller' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::0BlLVlLEqufM9Uun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LEXVdUjNBTXu7zmy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/vlans/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getVlans',
        'controller' => 'App\\Http\\Controllers\\OltController@getVlans',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LEXVdUjNBTXu7zmy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P4nMgLFHovtiXwbW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/pon/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'controller' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::P4nMgLFHovtiXwbW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d04NRj0UDkaVEAsP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::d04NRj0UDkaVEAsP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zp0IZObbAZeK17yz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/ponTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Zp0IZObbAZeK17yz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WSUQUJEdoP1Q952l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onuTypes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WSUQUJEdoP1Q952l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uNiQJ6FH6fCH56Sw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uNiQJ6FH6fCH56Sw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::83r8HNsb4c8bwn7H' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::83r8HNsb4c8bwn7H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WR6tvCLHglnSuW7o' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WR6tvCLHglnSuW7o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AEUfQGAUyQY25nqH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AEUfQGAUyQY25nqH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CF4qupq4a8hl8e3E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/vpn-tunnels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CF4qupq4a8hl8e3E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IQJxsuXGZIa5o3at' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IQJxsuXGZIa5o3at',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ua3JmUtNO3GjdoxK' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Ua3JmUtNO3GjdoxK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1CGhixmWstsBYFtr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1CGhixmWstsBYFtr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CpmmMHpLlQJ8SJFz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/portData/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CpmmMHpLlQJ8SJFz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NRwL58iYR0h90iBW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/uplink/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NRwL58iYR0h90iBW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pW34bfijsDFbKyWI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/oltcard/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pW34bfijsDFbKyWI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9N4IfdjmZ87SvU9B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/vlan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::9N4IfdjmZ87SvU9B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RaplG01G58iNjhqv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::RaplG01G58iNjhqv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b1yfok5HnqQE4VXQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/activeolt/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'controller' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::b1yfok5HnqQE4VXQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gxIWKqDWOUDyo9dI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/model/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::gxIWKqDWOUDyo9dI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y9Yx5RGR1tjxIW7p' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/catv/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Y9Yx5RGR1tjxIW7p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EbheAJNV8ZNDX9LX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::EbheAJNV8ZNDX9LX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FE8Ie2FupvOkSa2O' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/signal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'controller' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FE8Ie2FupvOkSa2O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CFtIemBl4yOJXXV1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/wan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'controller' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CFtIemBl4yOJXXV1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZPRIRUJfshK8LEKD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/mode/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZPRIRUJfshK8LEKD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dG6gsuam9ZKxCDNe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::dG6gsuam9ZKxCDNe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QWa1BfoTVnZGfMvJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QWa1BfoTVnZGfMvJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
