<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jUXy8trpNbXRQqQw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VgQ10F0eVw42MPFr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/tenancy/assets(?:/((?:.*)))?(*:36)|/api/company/([^/]++)(*:64)|/([^/]++)/(?|lo(?|g(?|in(*:95)|out(*:105))|cations(?|/(?|listing(*:135)|([^/]++)(?|(*:154)))|(*:164)))|c(?|hange/password(*:192)|apabilities(?|/(?|listing(*:225)|([^/]++)(?|(*:244)))|(*:254)))|user(?|/(?|listing(*:282)|([^/]++)(*:298)|roles/([^/]++)(*:320)|permissions/([^/]++)(*:348)|([^/]++)(?|(*:367)))|(*:377))|r(?|ole(?|/(?|listing(*:407)|([^/]++)(?|(*:426)))|(*:436))|eports(?|/(?|listing(*:465)|([^/]++)(*:481)|authorizations(*:503))|(*:512)))|p(?|ermission(?|/(?|listing(*:549)|([^/]++)(?|(*:568)))|(*:578))|onTypes/listing(*:602))|billing/(?|listing(*:629)|history(*:644)|([^/]++)(*:660)|history(*:675)|sendBill(*:691))|d(?|ashboard(?|(*:715)|/showByOlt/([^/]++)(*:742))|iagnostics(?|/(?|listing(*:775)|([^/]++)(?|(*:794)))|(*:804)))|o(?|dbs(?|/(?|listing(*:835)|([^/]++)(?|(*:854)))|(*:864))|nu(?|s(?|/(?|listing(*:893)|configured(*:911)|unconfigured(*:931)|([^/]++)(?|(*:950))|authorize/([^/]++)(*:977)|([^/]++)(*:993)|showbyOlt/([^/]++)(*:1019)|get_(?|all_status/([^/]++)(*:1054)|running_config/([^/]++)(*:1086)))|(*:1097)|_imports(*:1114))|Types(?|/(?|listing(*:1143)|([^/]++)(?|(*:1163)))|(*:1174)))|lts(?|/(?|listing(*:1202)|([^/]++)(?|(*:1222)))|(*:1233)))|speed_profiles(?|/(?|listing(*:1272)|([^/]++)(?|(*:1292)))|(*:1303))|get(?|_olts_uptime_and_env_temperature(*:1351)|/(?|hardware(*:1372)|s(?|oftware(*:1392)|nmp/(?|portData/([^/]++)(*:1425)|uplink/([^/]++)(*:1449)|o(?|ltcard/([^/]++)(*:1477)|nu(?|s/([^/]++)(*:1501)|/([^/]++)(*:1519)))|vlan/([^/]++)(*:1543)|activeolt/([^/]++)(*:1570)|mode(?|l/([^/]++)(*:1596)|/([^/]++)(*:1614))|catv/([^/]++)(*:1637)|s(?|tatus/([^/]++)(*:1664)|ignal/([^/]++)(*:1687))|wan/([^/]++)(*:1709)))|uplinks/([^/]++)(*:1736)|vlans/([^/]++)(*:1759)|pon/([^/]++)(*:1780)))|vpn\\-tunnels(?|/(?|listing(*:1817)|([^/]++)(?|(*:1837)))|(*:1848))))/?$}sDu',
    ),
    3 => 
    array (
      36 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stancl.tenancy.asset',
            'path' => NULL,
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O6RxCcbnpb6w5VSI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      95 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U71qxqXrkQCToFTn',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::93nmhRZI8cg1og1i',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      135 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WWgHfFznohkgvqI9',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RyU8dhMprucdeadK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::euDLOvUZVwuVzTsb',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xCQWKk12XX5dMbrf',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RP4wlDq5KZxYRSfs',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fuyx19RJtILLsUaJ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UqcHNVs8NKZrBdm8',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6YNVASrVXLLVPP2r',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zJi0DMl60qPXQrep',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::huy4nuMirgZprUZq',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yO9i1P5sfVdQJhqO',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::963oZPY2kRt6XP94',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VbCSKVCbgQpXv85Y',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FN6byQMcQcjkKSXO',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LTTyrWPhscHZ6BJ7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::51NpRcaH61ySQzQE',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NVtr0pMiBGleTCBA',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zsLsxpdzqdJw2kKR',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BlAjyxvEJEc9kM9G',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mljZm8bh4DRbUSPd',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rzh2oRLRTsW2Wus0',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::prQ5k8jzJr44TCoh',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IscCptq5hMvoWupb',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      465 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N1eGAhofHwQl1atx',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      481 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BBMhjmRpwsMqV9vk',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::STrUjz3TfnDjAWDI',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      512 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q2ULZlSrzu8ILV1b',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OmGFkH9BheCxDmFN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::66KAKwqr1d781oKp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qq3fzwMIhVcBhIml',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WMsTpJZdNbNP5KOs',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      578 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zwfOvcyVDiHuhVlI',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      602 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x2YaemHAzoQcmP5m',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      629 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w3O42fbnbUfNyNVV',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      644 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SARHqawNRskwxYSB',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U6obBvltBSLXdDRs',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      675 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OxGSvi0N9oWXUa9t',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1OdCQulGPo8jA5IE',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      715 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Nla9fdi5nECKQBBF',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QugnV6620PBeFGdd',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QagwYl22xwK232JN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      794 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HMQCqzkVCAgfcjnL',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cn9xYGmU6sio6lSe',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CqqsbrQbyIdRRjJK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r3cpbkVym9eQJB1h',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      835 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZtgrIlrBE7LUyXnM',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      854 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t1ixRfth9tEkFREP',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6dFHmQeSWtFaUsgf',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cOS6Odx2PqBmSMwq',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      864 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MzAJSo29QivlQP6L',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3uG4eVAdeibJDvjs',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      911 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BwRQz0ASNrbcVeNN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      931 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CvXBo3vhx2slt594',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      950 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JNmkYOPULIAInBU6',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UpS0YcNWPT5neYOS',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      977 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cp8HHScPduZlymuq',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      993 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vaHOANXG9Lzti7Vt',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1019 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KGgdKDPm6G7l779o',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1054 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8mYdHyRFKJC5Z6pg',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1086 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xDV55UReiWHAXNNQ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1097 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gXqTtquxZqPdrvtx',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wTYqqXwrYjJJiNTb',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1143 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WGvO2eKwLZENJGTI',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1163 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QMh3stGNQOiLNJNe',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aTojN0YKmStRbfJV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XyDWdERrYpRQ4tt1',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TcDCNbSDh287sQPv',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1202 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iGWJQAdC60XUlII6',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KmGLltmBmZG6WtLD',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LY6FQYgocvLozVDi',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NV2WpW0IuDw2GB8v',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8UqTHHW7vRN4DYfC',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::42RDEQAiUKBwxqtl',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1272 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::feSk325Yxj5m0s6v',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d9qcp6XcPw7Ts3Qs',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ld6qee9yfZOWoLjH',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yn8apndOiGg6SITB',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UxVfw4PCjxzZaV0r',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1351 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xivpKKtwn843z7Y4',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1372 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VTnUFEP7R2NekRbX',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZxUHkuCTGvv3oWjX',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UlBOEUVeGbVmtI1F',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1449 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bj3GMgsQMGSCgsS2',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AZJuj0S3BnpqnKHH',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1501 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::05xEcWTEnsWTARHB',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1519 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eFnxq6dp7BQl29k5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kfqXqwCAgJf4ZfpZ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1570 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PIOhsQruHpGLFjdR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EnypyqVgU1lm1jXB',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OahSSc5CINvsFHVR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pr45CY1vxvlAPmY7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9L4cTS8RuIlUYQ8P',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1687 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qqO4EJYur1nzVd3t',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1709 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4rsHWMo1fWgfISbu',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1736 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3J3oDcmzlqE2E12e',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1759 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JgAXi0Dut7YNEA2t',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XSH74RFPCQ0zTU6E',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1817 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lb0aFREfftYa3sne',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qPEyw5MIOfHNspqW',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IR2kdxe4D6M4oly2',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yQLHoU6h4TfWzPSG',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XDWQOScdxowoNHtj',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stancl.tenancy.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tenancy/assets/{path?}',
      'action' => 
      array (
        'uses' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'controller' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'as' => 'stancl.tenancy.asset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jUXy8trpNbXRQqQw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@registered',
        'controller' => 'App\\Http\\Controllers\\entity@registered',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jUXy8trpNbXRQqQw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O6RxCcbnpb6w5VSI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@show',
        'controller' => 'App\\Http\\Controllers\\entity@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::O6RxCcbnpb6w5VSI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VgQ10F0eVw42MPFr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007360000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VgQ10F0eVw42MPFr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U71qxqXrkQCToFTn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::U71qxqXrkQCToFTn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fuyx19RJtILLsUaJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/change/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fuyx19RJtILLsUaJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::963oZPY2kRt6XP94' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::963oZPY2kRt6XP94',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BlAjyxvEJEc9kM9G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\RoleController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::BlAjyxvEJEc9kM9G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IscCptq5hMvoWupb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\RoleController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IscCptq5hMvoWupb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mljZm8bh4DRbUSPd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@show',
        'controller' => 'App\\Http\\Controllers\\RoleController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::mljZm8bh4DRbUSPd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rzh2oRLRTsW2Wus0' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Rzh2oRLRTsW2Wus0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::prQ5k8jzJr44TCoh' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\RoleController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::prQ5k8jzJr44TCoh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OmGFkH9BheCxDmFN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@index',
        'controller' => 'App\\Http\\Controllers\\PermissionController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::OmGFkH9BheCxDmFN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zwfOvcyVDiHuhVlI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/permission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@store',
        'controller' => 'App\\Http\\Controllers\\PermissionController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zwfOvcyVDiHuhVlI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::66KAKwqr1d781oKp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@show',
        'controller' => 'App\\Http\\Controllers\\PermissionController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::66KAKwqr1d781oKp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qq3fzwMIhVcBhIml' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@update',
        'controller' => 'App\\Http\\Controllers\\PermissionController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qq3fzwMIhVcBhIml',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WMsTpJZdNbNP5KOs' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WMsTpJZdNbNP5KOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zsLsxpdzqdJw2kKR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zsLsxpdzqdJw2kKR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VbCSKVCbgQpXv85Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::VbCSKVCbgQpXv85Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FN6byQMcQcjkKSXO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getRoles',
        'controller' => 'App\\Http\\Controllers\\UserController@getRoles',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FN6byQMcQcjkKSXO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LTTyrWPhscHZ6BJ7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/permissions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'controller' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LTTyrWPhscHZ6BJ7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::51NpRcaH61ySQzQE' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::51NpRcaH61ySQzQE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NVtr0pMiBGleTCBA' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NVtr0pMiBGleTCBA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w3O42fbnbUfNyNVV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/billing/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@index',
        'controller' => 'App\\Http\\Controllers\\BillingController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::w3O42fbnbUfNyNVV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SARHqawNRskwxYSB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/billing/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@history',
        'controller' => 'App\\Http\\Controllers\\BillingController@history',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::SARHqawNRskwxYSB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U6obBvltBSLXdDRs' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/billing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@update',
        'controller' => 'App\\Http\\Controllers\\BillingController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::U6obBvltBSLXdDRs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OxGSvi0N9oWXUa9t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/billing/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@storeHistory',
        'controller' => 'App\\Http\\Controllers\\BillingController@storeHistory',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::OxGSvi0N9oWXUa9t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1OdCQulGPo8jA5IE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/billing/sendBill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\BillMailController@sendBill',
        'controller' => 'App\\Http\\Controllers\\BillMailController@sendBill',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1OdCQulGPo8jA5IE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Nla9fdi5nECKQBBF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Nla9fdi5nECKQBBF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QugnV6620PBeFGdd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard/showByOlt/{olt_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QugnV6620PBeFGdd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WWgHfFznohkgvqI9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@getData',
        'controller' => 'App\\Http\\Controllers\\ZoneController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WWgHfFznohkgvqI9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RP4wlDq5KZxYRSfs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@store',
        'controller' => 'App\\Http\\Controllers\\ZoneController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::RP4wlDq5KZxYRSfs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RyU8dhMprucdeadK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@show',
        'controller' => 'App\\Http\\Controllers\\ZoneController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::RyU8dhMprucdeadK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::euDLOvUZVwuVzTsb' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@update',
        'controller' => 'App\\Http\\Controllers\\ZoneController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::euDLOvUZVwuVzTsb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xCQWKk12XX5dMbrf' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'controller' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::xCQWKk12XX5dMbrf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZtgrIlrBE7LUyXnM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@getData',
        'controller' => 'App\\Http\\Controllers\\OdbsController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZtgrIlrBE7LUyXnM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MzAJSo29QivlQP6L' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/odbs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@store',
        'controller' => 'App\\Http\\Controllers\\OdbsController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::MzAJSo29QivlQP6L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t1ixRfth9tEkFREP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@show',
        'controller' => 'App\\Http\\Controllers\\OdbsController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::t1ixRfth9tEkFREP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6dFHmQeSWtFaUsgf' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@update',
        'controller' => 'App\\Http\\Controllers\\OdbsController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::6dFHmQeSWtFaUsgf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cOS6Odx2PqBmSMwq' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'controller' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cOS6Odx2PqBmSMwq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UqcHNVs8NKZrBdm8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UqcHNVs8NKZrBdm8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yO9i1P5sfVdQJhqO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/capabilities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@store',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::yO9i1P5sfVdQJhqO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6YNVASrVXLLVPP2r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@show',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::6YNVASrVXLLVPP2r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zJi0DMl60qPXQrep' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@update',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zJi0DMl60qPXQrep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::huy4nuMirgZprUZq' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::huy4nuMirgZprUZq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N1eGAhofHwQl1atx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@index',
        'controller' => 'App\\Http\\Controllers\\ReportController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::N1eGAhofHwQl1atx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q2ULZlSrzu8ILV1b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@store',
        'controller' => 'App\\Http\\Controllers\\ReportController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::q2ULZlSrzu8ILV1b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BBMhjmRpwsMqV9vk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/reports/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@destroy',
        'controller' => 'App\\Http\\Controllers\\ReportController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::BBMhjmRpwsMqV9vk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::STrUjz3TfnDjAWDI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/authorizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'controller' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::STrUjz3TfnDjAWDI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QagwYl22xwK232JN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QagwYl22xwK232JN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r3cpbkVym9eQJB1h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/diagnostics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::r3cpbkVym9eQJB1h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HMQCqzkVCAgfcjnL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::HMQCqzkVCAgfcjnL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cn9xYGmU6sio6lSe' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cn9xYGmU6sio6lSe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CqqsbrQbyIdRRjJK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CqqsbrQbyIdRRjJK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3uG4eVAdeibJDvjs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@index',
        'controller' => 'App\\Http\\Controllers\\OnuController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3uG4eVAdeibJDvjs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BwRQz0ASNrbcVeNN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/configured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::BwRQz0ASNrbcVeNN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CvXBo3vhx2slt594' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/unconfigured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::CvXBo3vhx2slt594',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gXqTtquxZqPdrvtx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@store',
        'controller' => 'App\\Http\\Controllers\\OnuController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::gXqTtquxZqPdrvtx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JNmkYOPULIAInBU6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@show',
        'controller' => 'App\\Http\\Controllers\\OnuController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::JNmkYOPULIAInBU6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UpS0YcNWPT5neYOS' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@update',
        'controller' => 'App\\Http\\Controllers\\OnuController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UpS0YcNWPT5neYOS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cp8HHScPduZlymuq' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/authorize/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'controller' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Cp8HHScPduZlymuq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vaHOANXG9Lzti7Vt' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::vaHOANXG9Lzti7Vt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KGgdKDPm6G7l779o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/showbyOlt/{olt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::KGgdKDPm6G7l779o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8mYdHyRFKJC5Z6pg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_all_status/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8mYdHyRFKJC5Z6pg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xDV55UReiWHAXNNQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_running_config/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::xDV55UReiWHAXNNQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wTYqqXwrYjJJiNTb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus_imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::wTYqqXwrYjJJiNTb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::feSk325Yxj5m0s6v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::feSk325Yxj5m0s6v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UxVfw4PCjxzZaV0r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/speed_profiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UxVfw4PCjxzZaV0r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d9qcp6XcPw7Ts3Qs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::d9qcp6XcPw7Ts3Qs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ld6qee9yfZOWoLjH' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Ld6qee9yfZOWoLjH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Yn8apndOiGg6SITB' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Yn8apndOiGg6SITB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iGWJQAdC60XUlII6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getData',
        'controller' => 'App\\Http\\Controllers\\OltController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::iGWJQAdC60XUlII6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8UqTHHW7vRN4DYfC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@store',
        'controller' => 'App\\Http\\Controllers\\OltController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8UqTHHW7vRN4DYfC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KmGLltmBmZG6WtLD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@show',
        'controller' => 'App\\Http\\Controllers\\OltController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::KmGLltmBmZG6WtLD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LY6FQYgocvLozVDi' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@update',
        'controller' => 'App\\Http\\Controllers\\OltController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LY6FQYgocvLozVDi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NV2WpW0IuDw2GB8v' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@destroy',
        'controller' => 'App\\Http\\Controllers\\OltController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NV2WpW0IuDw2GB8v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::42RDEQAiUKBwxqtl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@paginater',
        'controller' => 'App\\Http\\Controllers\\OltController@paginater',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::42RDEQAiUKBwxqtl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xivpKKtwn843z7Y4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get_olts_uptime_and_env_temperature',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'controller' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::xivpKKtwn843z7Y4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VTnUFEP7R2NekRbX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getHardware',
        'controller' => 'App\\Http\\Controllers\\OltController@getHardware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::VTnUFEP7R2NekRbX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZxUHkuCTGvv3oWjX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/software',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'controller' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZxUHkuCTGvv3oWjX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3J3oDcmzlqE2E12e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/uplinks/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'controller' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3J3oDcmzlqE2E12e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JgAXi0Dut7YNEA2t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/vlans/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getVlans',
        'controller' => 'App\\Http\\Controllers\\OltController@getVlans',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::JgAXi0Dut7YNEA2t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XSH74RFPCQ0zTU6E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/pon/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'controller' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::XSH74RFPCQ0zTU6E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WGvO2eKwLZENJGTI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WGvO2eKwLZENJGTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x2YaemHAzoQcmP5m' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/ponTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::x2YaemHAzoQcmP5m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TcDCNbSDh287sQPv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onuTypes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::TcDCNbSDh287sQPv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QMh3stGNQOiLNJNe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QMh3stGNQOiLNJNe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aTojN0YKmStRbfJV' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::aTojN0YKmStRbfJV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XyDWdERrYpRQ4tt1' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::XyDWdERrYpRQ4tt1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lb0aFREfftYa3sne' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Lb0aFREfftYa3sne',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XDWQOScdxowoNHtj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/vpn-tunnels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::XDWQOScdxowoNHtj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qPEyw5MIOfHNspqW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qPEyw5MIOfHNspqW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IR2kdxe4D6M4oly2' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IR2kdxe4D6M4oly2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yQLHoU6h4TfWzPSG' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::yQLHoU6h4TfWzPSG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UlBOEUVeGbVmtI1F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/portData/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UlBOEUVeGbVmtI1F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bj3GMgsQMGSCgsS2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/uplink/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::bj3GMgsQMGSCgsS2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AZJuj0S3BnpqnKHH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/oltcard/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AZJuj0S3BnpqnKHH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kfqXqwCAgJf4ZfpZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/vlan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::kfqXqwCAgJf4ZfpZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::05xEcWTEnsWTARHB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::05xEcWTEnsWTARHB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PIOhsQruHpGLFjdR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/activeolt/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'controller' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::PIOhsQruHpGLFjdR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EnypyqVgU1lm1jXB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/model/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::EnypyqVgU1lm1jXB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pr45CY1vxvlAPmY7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/catv/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pr45CY1vxvlAPmY7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9L4cTS8RuIlUYQ8P' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::9L4cTS8RuIlUYQ8P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qqO4EJYur1nzVd3t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/signal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'controller' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::qqO4EJYur1nzVd3t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4rsHWMo1fWgfISbu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/wan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'controller' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4rsHWMo1fWgfISbu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OahSSc5CINvsFHVR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/mode/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::OahSSc5CINvsFHVR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eFnxq6dp7BQl29k5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::eFnxq6dp7BQl29k5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::93nmhRZI8cg1og1i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'tenant',
          1 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          2 => 'auth.key',
          3 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::93nmhRZI8cg1og1i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
