<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sLKNe5ELf1uNr2Re',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hvaYYnQUmte012ag',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GjQHPZ4s37OclXhY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/tenancy/assets(?:/((?:.*)))?(*:36)|/api/company/([^/]++)(*:64)|/([^/]++)/(?|lo(?|g(?|in(*:95)|out(*:105))|cations(?|/(?|listing(*:135)|([^/]++)(?|(*:154)))|(*:164)))|c(?|hange/password(*:192)|apabilities(?|/(?|listing(*:225)|([^/]++)(?|(*:244)))|(*:254)))|user(?|/(?|listing(*:282)|([^/]++)(*:298)|roles/([^/]++)(*:320)|permissions/([^/]++)(*:348)|([^/]++)(?|(*:367)))|(*:377))|r(?|ole(?|/(?|listing(*:407)|([^/]++)(?|(*:426)))|(*:436))|eports(?|/(?|listing(*:465)|([^/]++)(*:481)|authorizations(*:503))|(*:512)))|p(?|ermission(?|/(?|listing(*:549)|([^/]++)(?|(*:568)))|(*:578))|onTypes/listing(*:602))|billing/listing(*:626)|d(?|ashboard(?|(*:649)|/showByOlt/([^/]++)(*:676))|iagnostics(?|/(?|listing(*:709)|([^/]++)(?|(*:728)))|(*:738)))|o(?|dbs(?|/(?|listing(*:769)|([^/]++)(?|(*:788)))|(*:798))|nu(?|s(?|/(?|listing(*:827)|configured(*:845)|unconfigured(*:865)|([^/]++)(?|(*:884))|authorize/([^/]++)(*:911)|([^/]++)(*:927)|showbyOlt/([^/]++)(*:953)|get_(?|all_status/([^/]++)(*:987)|running_config/([^/]++)(*:1018)))|(*:1029)|_imports(*:1046))|Types(?|/(?|listing(*:1075)|([^/]++)(?|(*:1095)))|(*:1106)))|lts(?|/(?|listing(*:1134)|([^/]++)(?|(*:1154)))|(*:1165)))|speed_profiles(?|/(?|listing(*:1204)|([^/]++)(?|(*:1224)))|(*:1235))|get(?|_olts_uptime_and_env_temperature(*:1283)|/(?|hardware(*:1304)|s(?|oftware(*:1324)|nmp/(?|portData/([^/]++)(*:1357)|uplink/([^/]++)(*:1381)|o(?|ltcard/([^/]++)(*:1409)|nu(?|s/([^/]++)(*:1433)|/([^/]++)(*:1451)))|vlan/([^/]++)(*:1475)|activeolt/([^/]++)(*:1502)|mode(?|l/([^/]++)(*:1528)|/([^/]++)(*:1546))|catv/([^/]++)(*:1569)|s(?|tatus/([^/]++)(*:1596)|ignal/([^/]++)(*:1619))|wan/([^/]++)(*:1641)))|uplinks/([^/]++)(*:1668)|vlans/([^/]++)(*:1691)|pon/([^/]++)(*:1712)))|vpn\\-tunnels(?|/(?|listing(*:1749)|([^/]++)(?|(*:1769)))|(*:1780))))/?$}sDu',
    ),
    3 => 
    array (
      36 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stancl.tenancy.asset',
            'path' => NULL,
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FHE83i0nWltRM6hN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      95 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xlIs1U78VfeRpLep',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NRsAgoRWZcpcOAwy',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      135 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BlmDXQrLje4gR1Z8',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::06l7OvWD807DQgO7',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZeMccsjZKKFSyYdJ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SoiS2DY3o1akGZ9q',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iXuCjqyAnUOP857S',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::okbhtnm6LqMlthug',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VBpfIDGH7x4hxZgP',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dlthLXEA8s9sJDTc',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gfmjXkv2HMzmkSHr',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JganegLYM6gVryM4',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1uc9p5nHTemw4J6S',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tjUGpOP8IDlGYV2i',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jH8mxNT2Lk9dgtyl',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bihbxd46qQhc0Hyn',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fv2zKuml7r0XdRdq',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IskqmOkFiJkWJ5CK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ceLslJT6XYSnuwaf',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hwSE1op2eZXYcn0c',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AOwLDEbLcg1e4tMs',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cE2EBE86MsiPAEpp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3do0xCV6QHst2W9x',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PXAWU9q66Hzpc9nn',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8vS2liPkAfInargb',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      465 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cSqVzQvCT6TvTY7u',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      481 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kiuZuHRFfVOjt5JB',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VGf97jCLpyjGc0tt',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      512 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iKta1iFIULHkxltl',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M9iZWLfKawKU2OgO',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0LXaT7DLr5UONbgL',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::faX9uNoNSc0iPQFI',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QWTA6fjvlThHWRnp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      578 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LmfWs7WYRvZ44Szz',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      602 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OOwx5FePlmv8pric',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      626 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lOChMOSorZZudb0C',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      649 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9ciponMmn5yHlU1C',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0dNphDjOTYhW7SwV',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      709 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6gllnAL22tCJzg49',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UPar1abpJXQ1mnip',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::15fy4pOJcYWGspMb',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aXQKjva0hoyP64js',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      738 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TZ6njXZecWcMWAqE',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IMF52wAPVWK3rg7Z',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      788 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::knASQuasyhcCaOSX',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FiR1b5YtTyvhxtxl',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lZSKmpY6Rm21GW7H',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jch0ul3qmmoNKctX',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      827 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lRVkuB5jE9cmYDgS',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      845 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1R9zXY0fEII6FY5E',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      865 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C2LgvHCH1f0aresb',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      884 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0m9ttwG63hZrpvh5',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i3oOCUO49AAR0mxh',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      911 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zLFWmYdYNdQBt9XD',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      927 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TnfEvZHH2AUDA1OI',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      953 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D3K4TaFXHpkhBene',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'olt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      987 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DZczgkb4bQRXVfUw',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V3Pwm7pO7wCYHv9z',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'external_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1029 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pR7kOa0Iccmsd59Y',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1046 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zdj1QN86e3u1OpKh',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1075 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XjQ4iHfCuFkhDAWo',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1095 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ihw4CNabUldlsWzT',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1XXk3r3N9fq0RxjN',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u0yk2OAhwOe3a7DK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1106 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xs1gbgURy65zh8pN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1134 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PBP9z9CEnhLwHyvN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LcU7cwMJPk3lCv9F',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bUYioCEVZAgr0VdQ',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BEpA3r87uZXyt7DN',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cj1QZ2Wy3cOtDqFQ',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wh4BBQsUnldkviKD',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1204 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fC34PMJ2x4ZtdL0Q',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1224 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FGW9EnakYJWchmiu',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4zYdbRh2XjAF2dv2',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R2YTfLJlkBhHaY56',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P8ThKCNiGYYLcumd',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::74S1stJAON5LGtDB',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::I1SN6HONMq28LYvu',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pzoivnaphMhVj8mT',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1357 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6STeOthmZ1LoDwQm',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1381 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kuFZzYa8ai5CfGMR',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1409 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8xU9dCit8OwLRcGi',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uVuU2XwGdLf6sNyr',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1451 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K5D9uY1PHZ8z22ng',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1475 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HR2vobhlDCfF5xJj',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1502 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WxvFC6fooy4GzzhB',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3tE43esJNNEm1oad',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p3dNruodWvFMijO9',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FEEBcJ7QXYUrPrTC',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lycc2laZkuCSVt2t',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1619 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FZv1BGBJWRnZwssO',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3rOXCYF6AApHRxJw',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::97qgcOS0HMEn5CZk',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NrO7BsKCahWQHC70',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uf9Om6CjtrhyOaK4',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1749 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vjRfkw4pjpSNA3A2',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m9q1rHbGZ57gF5Dp',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xW699d6LIiF4GaTj',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8fTVERrWFKDWDGoK',
          ),
          1 => 
          array (
            0 => 'tenant',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i1k3QNkcr7Bh5gzN',
          ),
          1 => 
          array (
            0 => 'tenant',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stancl.tenancy.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tenancy/assets/{path?}',
      'action' => 
      array (
        'uses' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'controller' => 'Stancl\\Tenancy\\Controllers\\TenantAssetsController@asset',
        'as' => 'stancl.tenancy.asset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sLKNe5ELf1uNr2Re' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@registered',
        'controller' => 'App\\Http\\Controllers\\entity@registered',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sLKNe5ELf1uNr2Re',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FHE83i0nWltRM6hN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\entity@show',
        'controller' => 'App\\Http\\Controllers\\entity@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FHE83i0nWltRM6hN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hvaYYnQUmte012ag' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000072a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hvaYYnQUmte012ag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GjQHPZ4s37OclXhY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@register',
        'namespace' => '',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GjQHPZ4s37OclXhY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xlIs1U78VfeRpLep' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::xlIs1U78VfeRpLep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::okbhtnm6LqMlthug' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/change/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@changePassword',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::okbhtnm6LqMlthug',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tjUGpOP8IDlGYV2i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::tjUGpOP8IDlGYV2i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AOwLDEbLcg1e4tMs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\RoleController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::AOwLDEbLcg1e4tMs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8vS2liPkAfInargb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\RoleController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8vS2liPkAfInargb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cE2EBE86MsiPAEpp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@show',
        'controller' => 'App\\Http\\Controllers\\RoleController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cE2EBE86MsiPAEpp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3do0xCV6QHst2W9x' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3do0xCV6QHst2W9x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PXAWU9q66Hzpc9nn' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\RoleController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::PXAWU9q66Hzpc9nn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M9iZWLfKawKU2OgO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@index',
        'controller' => 'App\\Http\\Controllers\\PermissionController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::M9iZWLfKawKU2OgO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LmfWs7WYRvZ44Szz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/permission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@store',
        'controller' => 'App\\Http\\Controllers\\PermissionController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LmfWs7WYRvZ44Szz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0LXaT7DLr5UONbgL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@show',
        'controller' => 'App\\Http\\Controllers\\PermissionController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::0LXaT7DLr5UONbgL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::faX9uNoNSc0iPQFI' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@update',
        'controller' => 'App\\Http\\Controllers\\PermissionController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::faX9uNoNSc0iPQFI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QWTA6fjvlThHWRnp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/permission/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\PermissionController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::QWTA6fjvlThHWRnp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hwSE1op2eZXYcn0c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::hwSE1op2eZXYcn0c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jH8mxNT2Lk9dgtyl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::jH8mxNT2Lk9dgtyl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bihbxd46qQhc0Hyn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getRoles',
        'controller' => 'App\\Http\\Controllers\\UserController@getRoles',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Bihbxd46qQhc0Hyn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fv2zKuml7r0XdRdq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/user/permissions/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'controller' => 'App\\Http\\Controllers\\UserController@getPermissions',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fv2zKuml7r0XdRdq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IskqmOkFiJkWJ5CK' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IskqmOkFiJkWJ5CK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ceLslJT6XYSnuwaf' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ceLslJT6XYSnuwaf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lOChMOSorZZudb0C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/billing/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\BillingController@index',
        'controller' => 'App\\Http\\Controllers\\BillingController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::lOChMOSorZZudb0C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9ciponMmn5yHlU1C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dashboard',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::9ciponMmn5yHlU1C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0dNphDjOTYhW7SwV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/dashboard/showByOlt/{olt_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\DashboardController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::0dNphDjOTYhW7SwV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BlmDXQrLje4gR1Z8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@getData',
        'controller' => 'App\\Http\\Controllers\\ZoneController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::BlmDXQrLje4gR1Z8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iXuCjqyAnUOP857S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@store',
        'controller' => 'App\\Http\\Controllers\\ZoneController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::iXuCjqyAnUOP857S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::06l7OvWD807DQgO7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@show',
        'controller' => 'App\\Http\\Controllers\\ZoneController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::06l7OvWD807DQgO7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZeMccsjZKKFSyYdJ' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@update',
        'controller' => 'App\\Http\\Controllers\\ZoneController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ZeMccsjZKKFSyYdJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SoiS2DY3o1akGZ9q' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/locations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'controller' => 'App\\Http\\Controllers\\ZoneController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::SoiS2DY3o1akGZ9q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IMF52wAPVWK3rg7Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@getData',
        'controller' => 'App\\Http\\Controllers\\OdbsController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::IMF52wAPVWK3rg7Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jch0ul3qmmoNKctX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/odbs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@store',
        'controller' => 'App\\Http\\Controllers\\OdbsController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Jch0ul3qmmoNKctX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::knASQuasyhcCaOSX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@show',
        'controller' => 'App\\Http\\Controllers\\OdbsController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::knASQuasyhcCaOSX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FiR1b5YtTyvhxtxl' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@update',
        'controller' => 'App\\Http\\Controllers\\OdbsController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FiR1b5YtTyvhxtxl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lZSKmpY6Rm21GW7H' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/odbs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'controller' => 'App\\Http\\Controllers\\OdbsController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::lZSKmpY6Rm21GW7H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VBpfIDGH7x4hxZgP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::VBpfIDGH7x4hxZgP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1uc9p5nHTemw4J6S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/capabilities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@store',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1uc9p5nHTemw4J6S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dlthLXEA8s9sJDTc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@show',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::dlthLXEA8s9sJDTc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gfmjXkv2HMzmkSHr' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@update',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::gfmjXkv2HMzmkSHr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JganegLYM6gVryM4' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/capabilities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'controller' => 'App\\Http\\Controllers\\CapabilityController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::JganegLYM6gVryM4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cSqVzQvCT6TvTY7u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@index',
        'controller' => 'App\\Http\\Controllers\\ReportController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cSqVzQvCT6TvTY7u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iKta1iFIULHkxltl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@store',
        'controller' => 'App\\Http\\Controllers\\ReportController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::iKta1iFIULHkxltl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kiuZuHRFfVOjt5JB' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/reports/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@destroy',
        'controller' => 'App\\Http\\Controllers\\ReportController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::kiuZuHRFfVOjt5JB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VGf97jCLpyjGc0tt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/reports/authorizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'controller' => 'App\\Http\\Controllers\\ReportController@lastAuthorizations',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::VGf97jCLpyjGc0tt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6gllnAL22tCJzg49' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::6gllnAL22tCJzg49',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TZ6njXZecWcMWAqE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/diagnostics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::TZ6njXZecWcMWAqE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UPar1abpJXQ1mnip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::UPar1abpJXQ1mnip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::15fy4pOJcYWGspMb' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::15fy4pOJcYWGspMb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aXQKjva0hoyP64js' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/diagnostics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'controller' => 'App\\Http\\Controllers\\DiagnosticController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::aXQKjva0hoyP64js',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lRVkuB5jE9cmYDgS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@index',
        'controller' => 'App\\Http\\Controllers\\OnuController@index',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::lRVkuB5jE9cmYDgS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1R9zXY0fEII6FY5E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/configured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@configuredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1R9zXY0fEII6FY5E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C2LgvHCH1f0aresb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/unconfigured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@unconfiguredOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::C2LgvHCH1f0aresb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pR7kOa0Iccmsd59Y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@store',
        'controller' => 'App\\Http\\Controllers\\OnuController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pR7kOa0Iccmsd59Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0m9ttwG63hZrpvh5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@show',
        'controller' => 'App\\Http\\Controllers\\OnuController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::0m9ttwG63hZrpvh5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i3oOCUO49AAR0mxh' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@update',
        'controller' => 'App\\Http\\Controllers\\OnuController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::i3oOCUO49AAR0mxh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zLFWmYdYNdQBt9XD' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onus/authorize/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'controller' => 'App\\Http\\Controllers\\OnuController@authorize_onu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::zLFWmYdYNdQBt9XD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TnfEvZHH2AUDA1OI' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::TnfEvZHH2AUDA1OI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D3K4TaFXHpkhBene' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/showbyOlt/{olt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'controller' => 'App\\Http\\Controllers\\OnuController@showByOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::D3K4TaFXHpkhBene',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DZczgkb4bQRXVfUw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_all_status/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuFullStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::DZczgkb4bQRXVfUw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V3Pwm7pO7wCYHv9z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onus/get_running_config/{external_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'controller' => 'App\\Http\\Controllers\\OnuController@getOnuRunningConfig',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::V3Pwm7pO7wCYHv9z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zdj1QN86e3u1OpKh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onus_imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'controller' => 'App\\Http\\Controllers\\OnuController@importOnus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Zdj1QN86e3u1OpKh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fC34PMJ2x4ZtdL0Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::fC34PMJ2x4ZtdL0Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P8ThKCNiGYYLcumd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/speed_profiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::P8ThKCNiGYYLcumd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FGW9EnakYJWchmiu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FGW9EnakYJWchmiu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4zYdbRh2XjAF2dv2' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::4zYdbRh2XjAF2dv2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R2YTfLJlkBhHaY56' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/speed_profiles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\SpeedProfileController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::R2YTfLJlkBhHaY56',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PBP9z9CEnhLwHyvN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getData',
        'controller' => 'App\\Http\\Controllers\\OltController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::PBP9z9CEnhLwHyvN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cj1QZ2Wy3cOtDqFQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@store',
        'controller' => 'App\\Http\\Controllers\\OltController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::cj1QZ2Wy3cOtDqFQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LcU7cwMJPk3lCv9F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@show',
        'controller' => 'App\\Http\\Controllers\\OltController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::LcU7cwMJPk3lCv9F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bUYioCEVZAgr0VdQ' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@update',
        'controller' => 'App\\Http\\Controllers\\OltController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::bUYioCEVZAgr0VdQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BEpA3r87uZXyt7DN' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/olts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@destroy',
        'controller' => 'App\\Http\\Controllers\\OltController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::BEpA3r87uZXyt7DN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wh4BBQsUnldkviKD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/olts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@paginater',
        'controller' => 'App\\Http\\Controllers\\OltController@paginater',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::wh4BBQsUnldkviKD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::74S1stJAON5LGtDB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get_olts_uptime_and_env_temperature',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'controller' => 'App\\Http\\Controllers\\OltController@getOltTemperature',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::74S1stJAON5LGtDB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::I1SN6HONMq28LYvu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getHardware',
        'controller' => 'App\\Http\\Controllers\\OltController@getHardware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::I1SN6HONMq28LYvu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pzoivnaphMhVj8mT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/software',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'controller' => 'App\\Http\\Controllers\\OltController@getSoftware',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::pzoivnaphMhVj8mT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::97qgcOS0HMEn5CZk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/uplinks/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'controller' => 'App\\Http\\Controllers\\OltController@getUplinks',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::97qgcOS0HMEn5CZk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NrO7BsKCahWQHC70' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/vlans/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getVlans',
        'controller' => 'App\\Http\\Controllers\\OltController@getVlans',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NrO7BsKCahWQHC70',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uf9Om6CjtrhyOaK4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/pon/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'controller' => 'App\\Http\\Controllers\\OltController@getPONPort',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uf9Om6CjtrhyOaK4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XjQ4iHfCuFkhDAWo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::XjQ4iHfCuFkhDAWo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OOwx5FePlmv8pric' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/ponTypes/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@getPonTypes',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::OOwx5FePlmv8pric',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xs1gbgURy65zh8pN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/onuTypes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Xs1gbgURy65zh8pN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ihw4CNabUldlsWzT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::ihw4CNabUldlsWzT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1XXk3r3N9fq0RxjN' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::1XXk3r3N9fq0RxjN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u0yk2OAhwOe3a7DK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/onuTypes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'controller' => 'App\\Http\\Controllers\\OnuTypesController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::u0yk2OAhwOe3a7DK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vjRfkw4pjpSNA3A2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/listing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@getData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::vjRfkw4pjpSNA3A2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i1k3QNkcr7Bh5gzN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{tenant}/vpn-tunnels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@store',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::i1k3QNkcr7Bh5gzN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m9q1rHbGZ57gF5Dp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@show',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::m9q1rHbGZ57gF5Dp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xW699d6LIiF4GaTj' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@update',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::xW699d6LIiF4GaTj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8fTVERrWFKDWDGoK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{tenant}/vpn-tunnels/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'controller' => 'App\\Http\\Controllers\\VpnTunnelController@destroy',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8fTVERrWFKDWDGoK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6STeOthmZ1LoDwQm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/portData/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@ponPortsData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::6STeOthmZ1LoDwQm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kuFZzYa8ai5CfGMR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/uplink/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@uplinkRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::kuFZzYa8ai5CfGMR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8xU9dCit8OwLRcGi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/oltcard/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@oltCardRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::8xU9dCit8OwLRcGi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HR2vobhlDCfF5xJj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/vlan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@vlanRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::HR2vobhlDCfF5xJj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uVuU2XwGdLf6sNyr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusData',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::uVuU2XwGdLf6sNyr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WxvFC6fooy4GzzhB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/activeolt/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'controller' => 'App\\Http\\Controllers\\SnmpController@activeOlt',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::WxvFC6fooy4GzzhB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3tE43esJNNEm1oad' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/model/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuType',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3tE43esJNNEm1oad',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FEEBcJ7QXYUrPrTC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/catv/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuCatv',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FEEBcJ7QXYUrPrTC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lycc2laZkuCSVt2t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuStatus',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::Lycc2laZkuCSVt2t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FZv1BGBJWRnZwssO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/signal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'controller' => 'App\\Http\\Controllers\\SnmpController@signal1310',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::FZv1BGBJWRnZwssO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3rOXCYF6AApHRxJw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/wan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'controller' => 'App\\Http\\Controllers\\SnmpController@wanModeOnu',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::3rOXCYF6AApHRxJw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p3dNruodWvFMijO9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/mode/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onuMode',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::p3dNruodWvFMijO9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K5D9uY1PHZ8z22ng' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/get/snmp/onu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'controller' => 'App\\Http\\Controllers\\SnmpController@onusRegister',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::K5D9uY1PHZ8z22ng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NRsAgoRWZcpcOAwy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{tenant}/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cors',
          2 => 'Stancl\\Tenancy\\Middleware\\InitializeTenancyByPath',
          3 => 'auth.key',
          4 => 'auth:sanctum',
          5 => 'cors',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'namespace' => '',
        'prefix' => '/{tenant}',
        'where' => 
        array (
        ),
        'as' => 'generated::NRsAgoRWZcpcOAwy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
